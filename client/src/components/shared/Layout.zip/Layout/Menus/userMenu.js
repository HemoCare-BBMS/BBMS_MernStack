export const userMenu = [
    {
        name:'Inventory',
        path:"/",
        icon:"fa-solid fa-warehouse"
    },
    {
        name:'Donor',
        path:"/donor",
        icon:"fa-solid fa-hand-holding-medical"
    },
    {
        name:'Hospital',
        path:'/hospital',
        icon:'fa-solid fa-hospital'
    },
    {
        name:'Organization',
        path:'/organization',
        icon:'fa-solid fa-building-ngo'
    },
];